function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6jlsrX3Uo7l":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

