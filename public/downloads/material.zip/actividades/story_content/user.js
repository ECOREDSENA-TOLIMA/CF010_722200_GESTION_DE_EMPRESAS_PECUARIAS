function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6jZooGln5ri":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

